import './bootstrap';
import 'flowbite';
import.meta.glob(['../fonts/**',]);
